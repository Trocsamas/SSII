/*
 * ejemplos3.h
 *
 *  Created on: 23 oct. 2019
 *      Author: migueltoro
 */

#ifndef EJEMPLOS3_H_
#define EJEMPLOS3_H_

#include "../types/types.h"
#include "../types/iterables.h"
#include "../types/math2.h"
#include "../types/list.h"

void test_ejemplos3();


#endif /* EJEMPLOS3_H_ */
