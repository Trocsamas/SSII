

/*
 * Ejercicio62.h
 *
 *  Created on: 2 nov. 2018
 *      Author: Miguel Toro
 */

#ifndef EJERCICIO62_H_
#define EJERCICIO62_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "../types/dates.h"
#include "../types/types.h"
#include "../types/memory_heap.h"

#include "../types/iterables.h"
#include "../types/list.h"


void test_ejercicio62();
void tofileWHILE(char * file,time_t a,time_t b);
void tofileRec(char * file,time_t a,time_t b);

#endif /* EJERCICIO62_H_ */
