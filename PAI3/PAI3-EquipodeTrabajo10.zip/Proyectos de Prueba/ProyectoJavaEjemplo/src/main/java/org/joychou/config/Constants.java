package org.joychou.config;

public class Constants {

    private Constants() {
    }

    public static final String REMEMBER_ME_COOKIE = "rememberMe";
}
